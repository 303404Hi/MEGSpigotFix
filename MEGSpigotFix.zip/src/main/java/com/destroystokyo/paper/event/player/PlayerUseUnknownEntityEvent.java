package com.destroystokyo.paper.event.player;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 精准复刻 Paper 的 PlayerUseUnknownEntityEvent 类
 * 完全匹配 ModelEngine 的调用参数和 Paper API 定义
 */
public class PlayerUseUnknownEntityEvent extends PlayerEvent implements Cancellable {
    // Bukkit 事件标准 HandlerList
    private static final HandlerList handlers = new HandlerList();
    // 事件核心字段（与 Paper API 一致）
    private final int entityId;
    private final boolean attack;
    private final EquipmentSlot hand;
    @Nullable
    private final Vector interactVector;
    private boolean cancelled = false;

    /**
     * ModelEngine 调用的核心构造方法（必须与调用参数完全匹配）
     * @param player 交互的玩家
     * @param entityId 未知实体的ID
     * @param attack 是否为攻击行为
     * @param hand 交互使用的手（HAND/OFF_HAND）
     * @param interactVector 交互的向量坐标（可为null）
     */
    public PlayerUseUnknownEntityEvent(@NotNull Player player, int entityId, boolean attack, @NotNull EquipmentSlot hand, @Nullable Vector interactVector) {
        super(player);
        this.entityId = entityId;
        this.attack = attack;
        this.hand = hand;
        this.interactVector = interactVector;
    }

    // ------------------- Paper API 要求的 getter 方法 -------------------
    /**
     * 获取被交互的未知实体ID
     */
    public int getEntityId() {
        return this.entityId;
    }

    /**
     * 判断是否为攻击行为（玩家点击攻击）
     */
    public boolean isAttack() {
        return this.attack;
    }

    /**
     * 获取交互使用的手（HAND/OFF_HAND）
     */
    @NotNull
    public EquipmentSlot getHand() {
        return this.hand;
    }

    /**
     * 获取交互的向量坐标（相对于实体的位置）
     */
    @Nullable
    public Vector getInteractVector() {
        return this.interactVector;
    }

    /**
     * 获取交互的位置（Paper 额外提供的便捷方法）
     */
    @Nullable
    public Location getInteractLocation() {
        return this.interactVector == null ? null : new Location(this.getPlayer().getWorld(), this.interactVector.getX(), this.interactVector.getY(), this.interactVector.getZ());
    }

    // ------------------- Cancellable 接口实现 -------------------
    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    // ------------------- Bukkit 事件标准方法 -------------------
    @NotNull
    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    @NotNull
    public static HandlerList getHandlerList() {
        return handlers;
    }
}