package com.destroystokyo.paper.megfix;

import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Field;

public final class MEGSpigotFix extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        try {
            // 1. 找到目标类
            Class<?> craftItemStackClass = Class.forName("org.bukkit.craftbukkit.v1_20_R1.inventory.CraftItemStack");

            // 2. 找到目标字段 "handle"
            Field handleField = craftItemStackClass.getDeclaredField("handle");

            // 3. 强行设置为可访问！这就是核心所在
            handleField.setAccessible(true);

            getLogger().info("=== Patch: PlayerUseUnknownEntityEvent & EntityHandlerImpl for ModelEngine is enabled ===");
            getLogger().info("=== Hope you enjoy your ModelEngine ===");

        } catch (Exception e) {
            getLogger().warning("=== Patch failed,make sure you are using 1.20.1 ===" + e.getMessage());
            e.printStackTrace();
        }


    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        getLogger().info("=== Patch: PlayerUseUnknownEntityEvent for ModelEngine is disabled ===");
    }
}
